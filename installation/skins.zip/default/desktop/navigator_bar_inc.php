<?php echo(build_post_page_navigator($base_url, $pagination_info, $all_entry_post)); ?>
