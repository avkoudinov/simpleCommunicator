﻿<div  style="text-align:center;padding-top:70px">
<h2><?php echo_html(text("Installation")); ?></h2>
<a href="installation.php?desktop=1"><?php echo_html(text("DesktopVersion")); ?></a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>