<?php
header("location: forums.php");
?>