<?php
define('VERSION', '2.0.48');
define('RELEASE_DATE', '01.07.2025');
?>