<?php
define('VERSION', '2.0.16');
define('RELEASE_DATE', '27.01.2024');
?>