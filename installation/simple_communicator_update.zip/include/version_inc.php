<?php
define('VERSION', '2.0.15');
define('RELEASE_DATE', '14.01.2024');
?>