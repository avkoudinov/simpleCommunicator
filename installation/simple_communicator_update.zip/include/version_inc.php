<?php
define('VERSION', '2.0.45');
define('RELEASE_DATE', '30.05.2025');
?>