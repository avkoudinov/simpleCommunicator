<?php
define('VERSION', '2.0.57');
define('RELEASE_DATE', '17.09.2025');
?>