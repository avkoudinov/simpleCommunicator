<?php
define('VERSION', '2.0.46');
define('RELEASE_DATE', '19.06.2025');
?>