<?php
define('VERSION', '2.0.56');
define('RELEASE_DATE', '12.09.2025');
?>