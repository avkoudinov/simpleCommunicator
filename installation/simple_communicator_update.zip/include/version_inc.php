<?php
define('VERSION', '2.0.55');
define('RELEASE_DATE', '10.09.2025');
?>