<?php
define('VERSION', '2.0.22');
define('RELEASE_DATE', '23.07.2024');
?>