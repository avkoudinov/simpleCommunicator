<?php
define('VERSION', '2.0.30');
define('RELEASE_DATE', '10.11.2024');
?>