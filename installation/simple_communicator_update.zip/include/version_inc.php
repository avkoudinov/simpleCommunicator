<?php
define('VERSION', '2.0.19');
define('RELEASE_DATE', '05.05.2024');
?>