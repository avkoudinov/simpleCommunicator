<?php
define('VERSION', '2.0.36');
define('RELEASE_DATE', '03.02.2025');
?>