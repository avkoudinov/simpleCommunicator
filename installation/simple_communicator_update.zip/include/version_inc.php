<?php
define('VERSION', '2.0.31');
define('RELEASE_DATE', '26.11.2024');
?>