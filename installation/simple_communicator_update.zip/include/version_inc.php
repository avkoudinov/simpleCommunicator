<?php
define('VERSION', '2.0.29');
define('RELEASE_DATE', '01.11.2024');
?>