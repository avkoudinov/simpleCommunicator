<?php
define('VERSION', '2.0.59');
define('RELEASE_DATE', '28.09.2025');
?>