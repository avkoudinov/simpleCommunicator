<?php
define('VERSION', '2.0.35');
define('RELEASE_DATE', '25.01.2025');
?>