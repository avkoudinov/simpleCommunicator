<?php
define('VERSION', '2.0.25');
define('RELEASE_DATE', '10.08.2024');
?>