<?php
define('VERSION', '2.0.24');
define('RELEASE_DATE', '30.07.2024');
?>