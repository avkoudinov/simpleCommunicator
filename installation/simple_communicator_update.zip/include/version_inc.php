<?php
define('VERSION', '2.0.52');
define('RELEASE_DATE', '28.07.2025');
?>