<?php
define('VERSION', '2.0.58');
define('RELEASE_DATE', '22.09.2025');
?>