<?php
define('VERSION', '2.0.41');
define('RELEASE_DATE', '20.04.2025');
?>