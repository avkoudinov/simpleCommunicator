DECLARE
  v_count NUMBER;
BEGIN
  -- Удаляем если существует (INCLUDING CONTENTS AND DATAFILES удалит все файлы автоматически)
  SELECT COUNT(*) INTO v_count FROM dba_tablespaces WHERE tablespace_name = UPPER('&1');
  IF v_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP TABLESPACE &1 INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS';
  END IF;

  -- Создаём с 4 datafile по 8GB каждый (итого до 128GB)
  EXECUTE IMMEDIATE 'CREATE TABLESPACE &1
    DATAFILE ''&1' || '_1.dbf'' SIZE 2000M AUTOEXTEND ON NEXT 200M MAXSIZE 32767M,
             ''&1' || '_2.dbf'' SIZE 2000M AUTOEXTEND ON NEXT 200M MAXSIZE 32767M,
             ''&1' || '_3.dbf'' SIZE 2000M AUTOEXTEND ON NEXT 200M MAXSIZE 32767M,
             ''&1' || '_4.dbf'' SIZE 2000M AUTOEXTEND ON NEXT 200M MAXSIZE 32767M';
END;
/
EXIT;