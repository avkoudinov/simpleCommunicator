charset utf8mb4;

/* create users */

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('prog02', '=====', 'Programmizd 02', 'programmizd02@gmail.com', '1', '2015-01-12 12:02:45', '2015-01-18 11:08:45', '1', 'Спасибо, что помог!', 'Строка 1
Строка 2', '1');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('esofter', '=====', 'Esofter', 'esofter@gmail.com', '0', '2015-01-12 12:02:45', '2014-11-18 11:08:45', '0', NULL, NULL, '2');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('ololo', '=====', 'ololo', 'ololo@gmail.com', '1', '2015-01-12 12:02:45', '2015-01-16 11:08:45', '0', 'У стейбла 25', NULL, '3');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('kima', '=====', 'kima', 'kima@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '4');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('dima', '=====', 'dima', 'dima@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '5');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('andrei', '=====', 'andrei', 'andrei@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '6');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('alex', '=====', 'alex', 'alex@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '7');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('sasha', '=====', 'sasha', 'sasha@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '8');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('sergei', '=====', 'sergei', 'sergei@gmail.com', '0', '2015-01-14 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '9');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('michail', '=====', 'michail', 'michail@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '10');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('gar', '=====', 'gar', 'gar@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '11');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('loft', '=====', 'loft', 'loft@gmail.com', '0', '2015-01-15 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '12');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('cat', '=====', 'cat', 'cat@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '13');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('dog', '=====', 'dog', 'dog@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '14');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('fox', '=====', 'fox', 'fox@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '15');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('bird', '=====', 'bird', 'bird@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '16');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('worm', '=====', 'worm', 'worm@gmail.com', '0', '2015-01-17 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '17');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('car', '=====', 'car', 'car@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '18');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('craw', '=====', 'craw', 'craw@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '19');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('fly', '=====', 'fly', 'fly@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '20');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('fish', '=====', 'fish', 'fish@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '21');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('bear', '=====', 'bear', 'bear@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '22');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('girl', '=====', 'girl', 'girl@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '23');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('boy', '=====', 'boy', 'boy@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '24');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('joy', '=====', 'joy', 'joy@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '25');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('knife', '=====', 'knife', 'knife@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '26');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('gun', '=====', 'gun', 'gun@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '27');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('sendal', '=====', 'sendal', 'sendal@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '28');

insert into v1_user (login, password_hash, user_name, email, hide_email, registration_date, last_visit_date, is_admin, message, info, read_marker)
values ('pasha', '=====', 'pasha with long nick', 'pasha@gmail.com', '0', '2015-01-12 12:02:45', '2015-01-17 11:08:45', '0', NULL, NULL, '29');

update v1_user set activated = '1', approved = '1', read_marker = md5(login);

/* create forums */

insert into v1_forum (name, creation_date, deleted)
values ('SQL', '2015-01-28 11:08:45', '0');

insert into v1_forum_moderator (user_id, forum_id) values (29, 2);
insert into v1_forum_moderator (user_id, forum_id) values (4, 2);
 
insert into v1_forum (name, description, creation_date, deleted)
values ('Prosto Trep', 'Razgovory.', '2015-01-10 10:08:45', '0');

insert into v1_forum_moderator (user_id, forum_id) values (29, 3);

insert into v1_forum (name, creation_date, deleted)
values ('AREA-51', '2015-01-22 17:08:45', '0');

insert into v1_forum_moderator (user_id, forum_id) values (29, 4);
insert into v1_forum_moderator (user_id, forum_id) values (27, 4);
insert into v1_forum_moderator (user_id, forum_id) values (22, 4);

insert into v1_forum (name, creation_date, deleted, closed)
values ('Ukraine', '2015-01-25 17:08:45', '0', '1');

insert into v1_forum_moderator (user_id, forum_id) values (11, 5);
insert into v1_forum_moderator (user_id, forum_id) values (4, 5);
insert into v1_forum_moderator (user_id, forum_id) values (12, 5);
insert into v1_forum_moderator (user_id, forum_id) values (13, 5);

insert into v1_forum (name, creation_date, deleted)
values ('Xren', '2015-01-22 17:08:45', '1');

insert into v1_forum_moderator (user_id, forum_id) values (29, 6);

update v1_settings set default_sender = 'andrei@gmail.com', receiver = 'andrei@gmail.com', whois_server = 'http://www.db.ripe.net/whois?form_type=simple&full_query_string=&searchtext={IP}&do_search=Search';

insert into v1_user_statistics (user_id)
select id from v1_user;

insert into v1_forum_statistics (forum_id)
select id from v1_forum;

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жук');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуки');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жука');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуку');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуков');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жукам');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуками');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуком');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуке');

insert into v1_morphology_dictionary
(root, word) values ('жук', 'жуках');