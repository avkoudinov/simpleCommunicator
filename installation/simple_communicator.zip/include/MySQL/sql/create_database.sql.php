<?php

$sql_cmds[] = '
create database if not exists $(DB_NAME)
';

?>