<?php
define('VERSION', '2.0.34');
define('RELEASE_DATE', '25.12.2024');
?>