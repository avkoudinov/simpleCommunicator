<?php
define('VERSION', '2.0.9');
define('RELEASE_DATE', '25.10.2023');
?>