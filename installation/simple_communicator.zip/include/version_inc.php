<?php
define('VERSION', '2.0.32');
define('RELEASE_DATE', '11.12.2024');
?>