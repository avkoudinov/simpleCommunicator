<?php
define('VERSION', '2.0.23');
define('RELEASE_DATE', '26.07.2024');
?>