<?php
define('VERSION', '2.0.39');
define('RELEASE_DATE', '24.02.2025');
?>