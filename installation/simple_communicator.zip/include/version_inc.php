<?php
define('VERSION', '2.0.33');
define('RELEASE_DATE', '24.12.2024');
?>