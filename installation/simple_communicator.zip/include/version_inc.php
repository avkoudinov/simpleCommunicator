<?php
define('VERSION', '2.0.38');
define('RELEASE_DATE', '07.02.2025');
?>