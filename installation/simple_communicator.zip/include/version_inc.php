<?php
define('VERSION', '2.0.17');
define('RELEASE_DATE', '24.02.2024');
?>