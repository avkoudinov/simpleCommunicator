<?php
define('VERSION', '2.0.53');
define('RELEASE_DATE', '18.08.2025');
?>