<?php
define('VERSION', '2.0.54');
define('RELEASE_DATE', '24.08.2025');
?>