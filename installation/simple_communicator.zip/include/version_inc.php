<?php
define('VERSION', '2.0.40');
define('RELEASE_DATE', '15.03.2025');
?>