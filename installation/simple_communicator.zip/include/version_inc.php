<?php
define('VERSION', '2.0.49');
define('RELEASE_DATE', '04.07.2025');
?>