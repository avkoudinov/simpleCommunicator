<?php
define('VERSION', '2.0.20');
define('RELEASE_DATE', '09.06.2024');
?>