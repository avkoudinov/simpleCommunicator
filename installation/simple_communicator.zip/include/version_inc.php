<?php
define('VERSION', '2.0.27');
define('RELEASE_DATE', '01.09.2024');
?>