<?php
define('VERSION', '2.0.26');
define('RELEASE_DATE', '29.08.2024');
?>