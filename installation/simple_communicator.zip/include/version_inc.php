<?php
define('VERSION', '2.0.21');
define('RELEASE_DATE', '16.07.2024');
?>