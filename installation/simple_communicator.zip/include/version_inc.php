<?php
define('VERSION', '2.0.37');
define('RELEASE_DATE', '05.02.2025');
?>