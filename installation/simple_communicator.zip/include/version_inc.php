<?php
define('VERSION', '2.0.42');
define('RELEASE_DATE', '26.05.2025');
?>