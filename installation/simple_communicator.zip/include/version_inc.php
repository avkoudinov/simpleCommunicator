<?php
define('VERSION', '2.0.51');
define('RELEASE_DATE', '27.07.2025');
?>