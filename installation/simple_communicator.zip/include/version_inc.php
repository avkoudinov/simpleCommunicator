<?php
define('VERSION', '2.0.28');
define('RELEASE_DATE', '02.09.2024');
?>