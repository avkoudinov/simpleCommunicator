<?php
define('VERSION', '2.0.47');
define('RELEASE_DATE', '30.06.2025');
?>