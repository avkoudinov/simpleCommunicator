<?php
// Admin password
define('ADMIN_PASSWORD', '');
?>